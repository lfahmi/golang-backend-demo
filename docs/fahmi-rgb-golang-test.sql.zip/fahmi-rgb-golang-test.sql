-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 21, 2023 at 04:03 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fahmi-rgb-nest-test`
--

CREATE DATABASE `fahmi-rgb-golang-test`;
USE `fahmi-rgb-golang-test`;

-- --------------------------------------------------------

--
-- Table structure for table `gifts`
--

CREATE TABLE `gifts` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `stock` double DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `cost` int(11) DEFAULT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gifts`
--

INSERT INTO `gifts` (`id`, `name`, `description`, `stock`, `created_at`, `updated_at`, `deleted_at`, `cost`, `created_by`) VALUES
(1, 'Samsung galaxy 5g 4/64gb', 'Ukuran Layar 6.2 inci, Dual Edge Super AMOLED', 10, '2023-12-21 21:04:58', '2023-12-21 21:04:58', NULL, 200000, 1),
(2, 'Xiaomi Redmi 5g 4/64gb', 'Ukuran Layar 6.4 inci, Dual Edge Super AMOLED', 8, '2023-12-21 21:04:58', '2023-12-21 21:04:58', NULL, 180000, 1),
(3, 'Samsung galaxy 5g 6/128gb', 'Ukuran Layar 6.2 inci, Dual Edge Super AMOLED', 10, '2023-12-21 21:04:58', '2023-12-21 21:04:58', NULL, 250000, 1),
(4, 'Xiaomi Redmi 5g 6/128gb', 'Ukuran Layar 6.4 inci, Dual Edge Super AMOLED', 8, '2023-12-21 21:04:58', '2023-12-21 21:04:58', NULL, 230000, 1),
(5, 'Gift Name Updated', 'This is description and it\'s updated', 5, '2023-12-21 21:05:10', '2023-12-21 21:08:14', NULL, 200000, 1),
(6, 'Test product 6', 'This is product description', 10, '2023-12-21 21:16:43', '2023-12-21 21:16:43', NULL, 200000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `gift_id` int(10) UNSIGNED DEFAULT NULL,
  `rate` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`id`, `user_id`, `gift_id`, `rate`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 1, 5, '2023-12-21 20:49:03', '2023-12-21 20:49:03', NULL),
(2, 1, 1, 1, '2023-12-21 20:49:03', '2023-12-21 20:49:03', NULL),
(3, 2, 1, 4, '2023-12-21 20:49:03', '2023-12-21 20:49:03', NULL),
(4, 1, 2, 4, '2023-12-21 20:49:03', '2023-12-21 20:49:03', NULL),
(5, 2, 2, 2, '2023-12-21 20:49:03', '2023-12-21 20:49:03', NULL),
(6, 1, 3, 5, '2023-12-21 20:49:03', '2023-12-21 20:49:03', NULL),
(7, 2, 3, 1, '2023-12-21 20:49:03', '2023-12-21 20:49:03', NULL),
(8, 1, 5, 5, '2023-12-21 21:08:31', '2023-12-21 21:08:31', NULL),
(9, 1, 5, 4, '2023-12-21 21:08:34', '2023-12-21 21:08:34', NULL),
(10, 1, 5, 5, '2023-12-21 21:08:39', '2023-12-21 21:08:39', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'user', 'user', '2023-12-21 20:47:50', '2023-12-21 20:47:50', NULL),
(2, 'john', 'doe', '2023-12-21 20:47:51', '2023-12-21 20:47:51', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gifts`
--
ALTER TABLE `gifts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_gifts_deleted_at` (`deleted_at`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ratings_deleted_at` (`deleted_at`),
  ADD KEY `ratings_gift_fk` (`gift_id`),
  ADD KEY `ratings_user_fk` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_users_deleted_at` (`deleted_at`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gifts`
--
ALTER TABLE `gifts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ratings`
--
ALTER TABLE `ratings`
  ADD CONSTRAINT `ratings_gift_fk` FOREIGN KEY (`gift_id`) REFERENCES `gifts` (`id`),
  ADD CONSTRAINT `ratings_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

CREATE USER 'rgbtest'@'%' IDENTIFIED BY 'rgbtest';
GRANT ALL PRIVILEGES ON `fahmi-rgb-golang-test`.* TO 'rgbtest'@'%';
FLUSH PRIVILEGES;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
